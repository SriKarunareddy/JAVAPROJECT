CREATE DATABASE shoppingcart2;
USE shoppingcart2;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(255) NOT NULL,
    image_path VARCHAR(255) NOT NULL  -- Column for image path
);

INSERT INTO products (name, price, category, image_path) VALUES 
('Apple', 0.99, 'Fruits', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\apple.jpg'),
('Banana', 0.59, 'Fruits', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\banana.jpg'),
('pomegranate', 1.49, 'Fruits', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\pomegranate.jpg'),
('Broccoli', 1.49, 'Vegetables', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\broccoli.jpg'),
('onion', 1.49, 'Vegetables', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\onion.jpg'),
('garlic', 1.49, 'Vegetables', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\garlic.jpg'),
('ginger', 1.49, 'Vegetables', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\ginger.jpg'),
('Milk', 1.49, 'Dairy', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\milk.jpg'),
('butter', 1.49, 'Dairy', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\butter.jpg'),
('chips', 1.49, 'Snacks', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\chips.jpg'),
('chocolates', 1.49, 'Snacks', 'C:\\Users\\VijayKarunakarReddy\\OneDrive\\Desktop\\New folder\\java\\chocolates.jpg');





CREATE TABLE transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    price DOUBLE NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE credits (
    username VARCHAR(255) PRIMARY KEY,
    credits DOUBLE DEFAULT 0
);
